from dataclasses import dataclass


@dataclass
class ProviderToken:
    key: str = None
